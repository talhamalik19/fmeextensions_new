<?php
/*////////////////////////////////////////////////////////////////////////////////
 \\\\\\\\\\\\\\\\\\\\\\\\\ Contactus extension\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 /////////////////////////////////////////////////////////////////////////////////
 \\\\\\\\\\\\\\\\\\\\\\\\\ NOTICE OF LICENSE\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 ///////                                                                   ///////
 \\\\\\\ This source file is subject to the Open Software License (OSL 3.0)\\\\\\\
 ///////   that is bundled with this package in the file LICENSE.txt.      ///////
 \\\\\\\   It is also available through the world-wide-web at this URL:    \\\\\\\
 ///////          http://opensource.org/licenses/osl-3.0.php               ///////
 \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 ///////                      * @category   FME                            ///////
 \\\\\\\                      * @package    FME_Contactus                  \\\\\\\
 ///////    * @author     Malik Tahir Mehmood <malik.tahir786@gmail.com>   ///////
 \\\\\\\                                                                   \\\\\\\
 /////////////////////////////////////////////////////////////////////////////////
 \\* @copyright  Copyright 2010 © free-magentoextensions.com All right reserved\\\
 /////////////////////////////////////////////////////////////////////////////////
 */

class FME_Contactus_Helper_Data extends Mage_Core_Helper_Abstract
{
    const XML_PATH_MAIN_ENABLE		= 'contactus/main/enable';
    const XML_PATH_REPLY_ENABLE		= 'contactus/reply/enable';
    const XML_PATH_REPLY_SUBJECT	= 'contactus/reply/subject';
    const XML_PATH_REPLY_BODY		= 'contactus/reply/body';
    const XML_PATH_EMAIL_RECIPIENT      = 'contacts/email/recipient_email';
    const XML_PATH_EMAIL_SENDER         = 'contacts/email/sender_email_identity';
    const XML_PATH_EMAIL_TEMPLATE       = 'contacts/email/email_template';


    public function getContactusEnable(){
		return Mage::getStoreConfig(self::XML_PATH_MAIN_ENABLE);
    }
    public function getSender(){
		return Mage::getStoreConfig(self::XML_PATH_EMAIL_SENDER);
    }
    public function getReceiver(){
		return Mage::getStoreConfig(self::XML_PATH_EMAIL_RECIPIENT);
    }
      public function getTemplate(){
		return Mage::getStoreConfig(self::XML_PATH_EMAIL_TEMPLATE);
    }
    public function getreplyEnable(){
		return Mage::getStoreConfig(self::XML_PATH_REPLY_ENABLE);
    }
    public function getsubject(){
		return Mage::getStoreConfig(self::XML_PATH_REPLY_SUBJECT);
    }
    public function getbody(){
		return Mage::getStoreConfig(self::XML_PATH_REPLY_BODY);
    }
    
    public function getUserName()
    {
        if (!Mage::getSingleton('customer/session')->isLoggedIn()) {
            return '';
        }
        $customer = Mage::getSingleton('customer/session')->getCustomer();
        return trim($customer->getName());
    }

    public function getUserEmail()
    {
        if (!Mage::getSingleton('customer/session')->isLoggedIn()) {
            return '';
        }
        $customer = Mage::getSingleton('customer/session')->getCustomer();
        return $customer->getEmail();
    }
    public function isenable(){
    
//        Mage::register('config', new Mage_Core_Model_Config());
//
//		if(self::getContactusEnable())
//                {
//                //Mage_Core_Model_Config::saveConfig('contacts/contacts/enabled','0');
//                
//                Mage::registry('config')->saveConfig('contacts/contacts/enabled','0');
//                 
//                }
//		else
//                {
//                    //Mage_Core_Model_Config::saveConfig('contacts/contacts/enabled','1');
//                             //Mage_Core_Model_Store::setConfig('contacts/contacts/enabled','1');
//                             
//                   Mage::registry('config')->saveConfig('contacts/contacts/enabled','1');
//                }
//                
		
    }
     public function getContactsUrl() {
        return Mage::getBaseUrl() . 'contacts/';
    }
    public function getContactusUrl() {
            return Mage::getUrl('contactus/index/email');
        }

}