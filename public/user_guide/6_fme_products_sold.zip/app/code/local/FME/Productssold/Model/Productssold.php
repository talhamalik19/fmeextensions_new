<?php
 /**
 * Products Sold Extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   FME
 * @package    FME_Productssold
 * @author     Mirza Tauseef<mirza.tauseef@live.com>
 * @author     developer@free-magentoextensions.com
 * @copyright  Copyright 2010 © free-magentoextensions.com All right reserved
 */
class FME_Productssold_Model_Productssold extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('productssold/productssold');
    }
     /*** Returns Orders against product id ****/
    public function getOrders($pid)
    {
     $ver=Mage::getVersion();
     if($ver=="1.4.1.1")
     {
        $mySql0 = "SELECT sum(s.qty_ordered) AS Ordered  FROM sales_flat_order_item s  inner join sales_flat_order o on s.order_id=o.entity_id  where s.product_id=". $pid ." and o.status='complete' GROUP BY s.product_id";
        $customerGroupId1 = Mage::getSingleton('core/resource') ->getConnection('core_read')->fetchAll($mySql0);
        $count= count($customerGroupId1);
        $sales1= "No Sales Yet";
         if($count!=0)
         {
                  $sales=explode('.',$customerGroupId1[0]['Ordered']);
                  $sales1=$sales[0];
                  $sales1.= " Total Sales";
                  return $sales1; 
         }
         else {
                  return $sales1;
              }
     }
    else
    {
        $mySql0 = "SELECT sum(s.qty_ordered) AS Ordered  FROM sales_flat_order_item s  inner join sales_order o on s.order_id=o.entity_id  where s.product_id=". $pid ." and o.status='complete' GROUP BY s.product_id";
        $customerGroupId1 = Mage::getSingleton('core/resource') ->getConnection('core_read')->fetchAll($mySql0);
        $count= count($customerGroupId1);
        $sales1= "No Sales Yet";
         if($count!=0)
         {
                  $sales=explode('.',$customerGroupId1[0]['Ordered']);
                  $sales1=$sales[0];
                  $sales1.= " Total Sales";
                  return $sales1; 
         }
         else {
                  return $sales1;
              }
    }
    }
        /*** Returns Fake Orders  ****/
    public function getProductSoldCollection($pid)
    {
        $real=array(); 
	$productssoldTable = Mage::getSingleton('core/resource')->getTableName('productssold');
	$sqry = "select realsaleslabel,offsiteorder from ".$productssoldTable." where productssold_id=". $pid ." ";
	//echo $sqry;
	$connection = Mage::getSingleton('core/resource')->getConnection('core_read');
	$select = $connection->query($sqry);
	$customrows = $select->fetchAll();
	$customdata=$customrows;
        return $customrows;
    }
    /*** Returns Real Orders  ****/
     public function getRealCollection($pid)
    {
        $ver=Mage::getVersion();
         if($ver=="1.4.1.1")
        {
            $selectqty = "SELECT sum(s.qty_ordered) AS Ordered  FROM sales_flat_order_item s  inner join sales_flat_order o on s.order_id=o.entity_id  where s.product_id=". $pid ." and o.status='complete' GROUP BY s.product_id";	
            $connection = Mage::getSingleton('core/resource')->getConnection('core_read');
            $select = $connection->query($selectqty);
            $rows = $select->fetchAll();
                if(!empty($rows))
                    {
                        return $rows;
                    }
                else
                    {
                        return 0;
                    }
        }
        else
        {
            $selectqty = "SELECT sum(s.qty_ordered) AS Ordered  FROM sales_flat_order_item s  inner join sales_order o on s.order_id=o.entity_id  where s.product_id=". $pid ." and o.status='complete' GROUP BY s.product_id";	
            $connection = Mage::getSingleton('core/resource')->getConnection('core_read');
            $select = $connection->query($selectqty);
            $rows = $select->fetchAll();
                if(!empty($rows))
                    {
                        return $rows;
                    }
                else
                    {
                        return 0;
                    }
        }
       
    }
}