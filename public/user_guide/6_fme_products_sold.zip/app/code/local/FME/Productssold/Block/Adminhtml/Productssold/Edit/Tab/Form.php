<?php
 /**
 * Products Sold Extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   FME
 * @package    FME_Productssold
 * @author     Mirza Tauseef<mirza.tauseef@live.com>
 * @author     developer@free-magentoextensions.com
 * @copyright  Copyright 2010 © free-magentoextensions.com All right reserved
 */
class FME_Productssold_Block_Adminhtml_Productssold_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
   public function __construct()
    {
        parent::__construct();
	
        $this->setUseAjax(true);
	echo '<script type="text/javascript" src="' . $this->getSkinUrl() . 'productssold/jquery-1.4.2.min.js"></script>';
	
    }
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('productssold_form', array('legend'=>Mage::helper('productssold')->__('Products Sold Information')));
      $url = $this->getUrl('*/*/edit', array('_current' => true));
      $pos=strripos($url,"entity_id");

     if($pos!="")
     {
      $DirPath=substr($url,$pos);
      $finalid=explode('/',$DirPath);
      $pid=$finalid[1];
      $_newProduct = Mage::getModel('catalog/product')->load($pid);
     }
     else
     {

      $pos=strripos($url,"id");
      $DirPath=substr($url,$pos);
      $finalid=explode('/',$DirPath);
      $pid=$finalid[1];
      $_newProduct = Mage::getModel('catalog/product')->load($pid);
     }

      $p_name=$_newProduct['name'];

      $fieldset->addField($p_name, 'label', array(
          'label'     => Mage::helper('productssold')->__('Product Name'),
          'required'  => false,
          'name'      => 'title',
	  'after_element_html' => $p_name,
      ));
	  
	  $stockHiddenFields = array(
			'use_config_min_qty'   => 1,
       );

	  
	   $fieldset->addField('prid', 'hidden', array(
          'label'     => Mage::helper('productssold')->__(''),
          'name'      => 'prid',
	  'id'      => 'prid'
      ));
	
		
      
     /*** Get Orders from Model ****/
     $sales1 = "<span id='real'>";      
     $sales1.=Mage::getModel('productssold/productssold')->getOrders($pid);
     $sales1.= "</span>";
     $fieldset->addField('realsaleslabel', 'text', array(
          'name'      => 'realsaleslabel',
          'label'     => Mage::helper('productssold')->__('Label'),
          'title'     => Mage::helper('productssold')->__('Label'),
          'required'  => true,
	  'class'     => 'validate-alpha',
	 
      ));
     
      $fieldset->addField('realsales', 'label', array(
          'name'      => 'realsales',
          'label'     => Mage::helper('productssold')->__('Actual No Of Order'),
          'title'     => Mage::helper('productssold')->__('Actual No Of Order'),
          'after_element_html' => $sales1,
	  
      ));
   
      $fieldset->addField('offsiteorder', 'text', array(
          'name'      => 'offsiteorder',
          'label'     => Mage::helper('productssold')->__('Off Site Order'),
          'title'     => Mage::helper('productssold')->__('Off Site Order'),
	  'class'     => 'validate-number',
         
      ));

   
   
     
      if ( Mage::getSingleton('adminhtml/session')->getProductssoldData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getProductssoldData());
          Mage::getSingleton('adminhtml/session')->setProductssoldData(null);
      } elseif ( Mage::registry('productssold_data') ) {
          $form->setValues(Mage::registry('productssold_data')->getData());
      }
      return parent::_prepareForm();
  }
   protected function _afterToHtml($html){
    	return $this->_prependHtml() . parent::_afterToHtml($html) . $this->_appendHtml();
    }

    
    private function _prependHtml(){
    		$gridName = $this->getJsObjectName();
	    	$test='php in javascript';
    	        	$html=
<<<EndHTML

	<script type="text/javascript">
	
	

        </script>
	
EndHTML;

    		return $html;
    }
    
    
    private function _appendHtml(){
    	$html= '';
    	return $html;
    }
}