<?php

class FME_Productssold_Model_Mysql4_Productssold extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the productssold_id refers to the key field in your database table.
        $this->_init('productssold/productssold', 'productssold_id');
    }
}