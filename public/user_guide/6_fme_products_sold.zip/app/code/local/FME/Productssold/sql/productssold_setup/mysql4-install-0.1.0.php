<?php
 /**
 * Products Sold Extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   FME
 * @package    FME_Productssold
 * @author     Mirza Tauseef<mirza.tauseef@live.com>
 * @author     developer@free-magentoextensions.com
 * @copyright  Copyright 2010 © free-magentoextensions.com All right reserved
 */
$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('productssold')};
CREATE TABLE {$this->getTable('productssold')} (
  `productssold_id` int(11) NOT NULL ,
  `name` varchar(255) NOT NULL default '',
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  `product_id` text NOT NULL,
  `realsaleslabel` text NOT NULL ,
  `offsiteorder` text NOT NULL 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");
$installer->setConfigData('productssold/list/description','1');
$installer->setConfigData('productssold/list/display','1');
$installer->endSetup(); 