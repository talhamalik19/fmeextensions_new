<?php
 /**
 * Products Sold Extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   FME
 * @package    FME_Productssold
 * @author     Mirza Tauseef<mirza.tauseef@live.com>
 * @author     developer@free-magentoextensions.com
 * @copyright  Copyright 2010 © free-magentoextensions.com All right reserved
 */
class FME_Productssold_Block_Adminhtml_Productssold_Grid extends Mage_Adminhtml_Block_Widget_Grid
{ 
  public function __construct()
    {
      parent::__construct();
      $this->setId('productssoldGrid');
      $this->setDefaultSort('entity_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
    }

     protected function _getStore()
    {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
    }
    
 public function getProduct()
    {
        return Mage::registry('product');
    }
   
    
 
     protected function _prepareCollection()
    {
        $store = $this->_getStore();
        
        $collection = Mage::getModel('catalog/product')->getCollection()
			->addAttributeToSelect('*')
			->addAttributeToFilter('status', 1)//enabled
			->addAttributeToFilter('visibility', 4);//catalog, search
            
    	if ($store->getId()) {
			
            $collection->addStoreFilter($store);
            $collection->joinAttribute('custom_name', 'catalog_product/name', 'entity_id', null, 'inner', $store->getId());
            $collection->joinAttribute('status', 'catalog_product/status', 'entity_id', null, 'inner', $store->getId());
            $collection->joinAttribute('visibility', 'catalog_product/visibility', 'entity_id', null, 'inner', $store->getId());
            $collection->joinAttribute('price', 'catalog_product/price', 'entity_id', null, 'left', $store->getId());
        }
        else {
	    
            $collection->addAttributeToSelect('*');
        }
            
              
        $this->setCollection($collection);

        
        parent::_prepareCollection();
        $this->getCollection()->addWebsiteNamesToResult();
        return $this;
    }    
   protected function _prepareColumns()
      {
	 $collection = Mage::getModel('catalog/product')->getCollection()
			->addAttributeToSelect('*')
			->addAttributeToFilter('status', 1)//enabled
			->addAttributeToFilter('visibility', 4);//catalog, search
     foreach($collection as $col)
     {
      //print_r($col);
      $pid=$col['entity_id'];
    //exit;
    $mySql0 = "SELECT productssold_id FROM productssold  where productssold_id=". $pid ."";
    $customerGroupId1 = Mage::getSingleton('core/resource') ->getConnection('core_read')->fetchAll($mySql0);
    $count= count($customerGroupId1);
   
    if($count==0)
    {
    $mySql1 = "insert into productssold (productssold_id,product_id) values ('$pid','$pid')";
    $customerGroupId1 = Mage::getSingleton('core/resource') ->getConnection('core_write')->query($mySql1);
    }
     }
     $this->addColumn('entity_id', array(
		      'header'    => Mage::helper('review')->__('ID'),
		      'width'     => '50px',
		      'index'     => 'entity_id',
         ));
 
         $this->addColumn('name', array(
                 'header'    => Mage::helper('review')->__('Name'),
                 'index'     => 'name',
         ));
 
         if ((int)$this->getRequest()->getParam('store', 0)) {
             $this->addColumn('custom_name', array(
                     'header'    => Mage::helper('review')->__('Name In Store'),
                     'index'     => 'custom_name'
             ));
         }
 
         $this->addColumn('sku', array(
                 'header'    => Mage::helper('review')->__('SKU'),
                 'width'     => '80px',
                 'index'     => 'sku'
         ));
 
         $this->addColumn('price', array(
                 'header'    => Mage::helper('review')->__('Price'),
                 'type'      => 'currency',
                 'index'     => 'price'
         ));
 

         
	 $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('productssold')->__('Action'),
                'width'     => '150px',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('productssold')->__('Add New Sold No'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'entity_id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
 
         /**
          * Check is single store mode
          */
         if (!Mage::app()->isSingleStoreMode()) {
             $this->addColumn('websites',
                 array(
                     'header'=> Mage::helper('review')->__('Websites'),
                     'width' => '100px',
                     'sortable'  => false,
                     'index'     => 'websites',
                     'type'      => 'options',
                     'options'   => Mage::getModel('core/website')->getCollection()->toOptionHash(),
             ));
         }
     }
 
    


    
}