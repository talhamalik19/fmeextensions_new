<?php
 /**
 * Products Sold Extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   FME
 * @package    FME_Productssold
 * @author     Mirza Tauseef<mirza.tauseef@live.com>
 * @author     developer@free-magentoextensions.com
 * @copyright  Copyright 2010 © free-magentoextensions.com All right reserved
 */
class FME_Productssold_Block_Productssold extends  Mage_Catalog_Block_Product_Abstract
{
      
      const XML_PATH_Product_Desc  = 'productssold/list/description';
      const XML_PATH_Product_Display  = 'productssold/list/display';
     
      public function getProductSoldDisplay()
	{
		return Mage::getStoreConfig(self::XML_PATH_Product_Display);
	}

       public function getProductSoldDescStatus()
	{
		return Mage::getStoreConfig(self::XML_PATH_Product_Desc);
	}

      public function _prepareLayout()
	{
	  return parent::_prepareLayout();
	}
    
      public function getProductssold()     
	{ 
		if (!$this->hasData('productssold')) {
		    $this->setData('productssold', Mage::registry('productssold'));
		}
		return $this->getData('productssold');
        
        }
    
}